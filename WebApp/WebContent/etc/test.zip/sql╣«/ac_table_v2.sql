/* ȸ�� ���� */
create table ac_user(
    userNo number(5) not null,
    user_passNo varchar2(100) primary key,
    user_id varchar2(20) not null,
    user_pwd varchar2(50) not null,
    user_name varchar2(20) not null,
    user_ename varchar2(20) not null,
    user_birth date,
    user_gender varchar2(10) not null,
    user_nation varchar2(10),
    user_tel varchar2(20) not null,
    user_email varchar2(200) not null,
    mileage number(10),
    grade varchar2(20)
);

/* ��������Ʈ*/
create table ac_blacklist(
    user_passNo varchar2(100),
    reason varchar2(200) not null,
    regDate date not null
);

/* ��������Ʈ*/
create table ac_blacklist2(
    black_passNo varchar2(100),
    black_name varchar2(20) not null,
    black_ename varchar2(20) not null,
    black_birth date not null,
    black_gender varchar2(10) not null,
    black_exDate date not null,
    reason varchar2(200) not null,
    regDate date not null
);

/* ���� ���� */
create table ac_reservation(
    resNo varchar2(20) primary key,
    resdate date not null,
    flightNo varchar2(10),
    brdDate date not null,
    user_passNo varchar2(100),
    user_exDate date
);

/* ���� ����(�պ��� ���) */
create table ac_seat(
    resNo varchar2(20) not null,
    seatNo varchar2(10) not null,
    meal varchar2(20)
);

/* ���� ����*/
create table ac_company(
    com_passNo varchar2(20) not null,
    com_name varchar2(20) not null,
    com_ename varchar2(20) not null,
    com_birth date not null,
    com_gender varchar2(10) not null,
    com_exDate date not null,
    com_nation varchar2(10) not null,
    com_tel varchar2(20) not null,
    com_email varchar2(200) not null,
    resNo varchar2(20) not null
);

/* �װ��� ����*/
create table ac_aircraft(
    regNo varchar2(10) primary key,
    ac_type varchar2(20) not null,
    ac_date date,
    ac_cfg number(5) not null,
    ac_wt number(5),
    regDate date
);

/* �װ��� ����*/
create table ac_flight(
    regNo varchar2(10) not null,
    flightNo varchar2(10) primary key,
    dep varchar2(10) not null,
    des varchar2(10) not null,
    depTime varchar2(10) not null,
    desTime varchar2(10) not null,
    flightTime varchar2(10),
    crew number(3),
    flight_state varchar2(10),
    fare number(10)
);

/* ����� ���� */
create table ac_dep(
    dep varchar2(30) primary key,
    dep_city varchar2(50),
    dep_airport varchar2(50)
);

/* ������ ���� */
create table ac_des(
    des varchar2(30) primary key,
    des_city varchar2(50),
    des_airport varchar2(50)
);

/* ��� ���� */
create table ac_employee(
    empNo varchar2(20) primary key,
    emp_name varchar2(20) not null,
    emp_ename varchar2(20),
    emp_birth date,
    emp_gender varchar2(10),
    emp_passNo varchar2(20),
    emp_exDate date,
    emp_nation varchar2(10),
    emp_tel varchar2(20),
    emp_email varchar2(200),
    emp_addr varchar2(200),
    emp_dept varchar2(50),
    emp_job varchar2(100),
    emp_date date
);

/* ž�½¹��� ���� */
create table ac_onboard_emp(
    empNo varchar2(20),
    emp_name varchar2(20) not null,
    emp_ename varchar2(20),
    flightNo varchar2(10)
);

/* foreign key */
alter table ac_reservation add constraint ac_reservation_fk_user_passNo foreign key (user_passNo) references ac_user (user_passNo);
alter table ac_reservation add constraint ac_reservation_fk_flightNo foreign key (flightNo) references ac_flight (flightNo);

alter table ac_reservation2 add constraint ac_reservation2_fk_resNo foreign key (resNo) references ac_reservation (resNo);

alter table ac_blacklist add constraint ac_blacklist_fk_user_passNo foreign key (user_passNo) references ac_user (user_passNo);

alter table ac_seat add constraint ac_seat_fk_resNo foreign key (resNo) references ac_reservation (resNo);

alter table ac_company add constraint ac_company_fk_resNo foreign key (resNo) references ac_reservation (resNo);

alter table ac_flight add constraint ac_flight_fk_regNo foreign key (regNo) references ac_aircraft (regNo);
alter table ac_flight add constraint ac_flight_fk_dep foreign key (dep) references ac_dep (dep);
alter table ac_flight add constraint ac_flight_fk_des foreign key (des) references ac_des (des);

select * from user_constraints;

/* ������ �Է� */
@d:\ac_aircraft.sql
select * from ac_aircraft;

@d:\ac_dep.sql
select * from ac_dep;

@d:\ac_des.sql
select * from ac_des;

@d:\ac_user.sql
select * from ac_user;

@d:\ac_employee.sql
select * from ac_employee;

@d:\ac_blacklist.sql
select * from ac_blacklist;

@d:\ac_blacklist2.sql
select * from ac_blacklist2;

@d:\ac_flight.sql
select * from ac_flight;

@d:\ac_reservation.sql
select * from ac_reservation;

@d:\ac_seat.sql
select * from ac_seat;

@d:\ac_company.sql
select * from ac_company;

commit;